package com.synnex.cis.demo.util;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.synnex.jee.web.WebUtil;

/**
 * Description:</br>
 * 
 * @author daniely
 *
 */
public class FacesUtils {

    private static String JETTY_IPV4 = null;
    
    static {
		String ipv4 = WebUtil.getIPv4Address();
		if(ipv4 == null) {
			JETTY_IPV4 = "000.000.";
		}else{
			String ipDigits[] = ipv4.split("\\.");
			int ipPos2 = Integer.valueOf(ipDigits[ipDigits.length - 2]);
			int ipPos3 = Integer.valueOf(ipDigits[ipDigits.length - 1]);
			JETTY_IPV4 = String.format("%03d", ipPos2) +"." + String.format("%03d", ipPos3) + ".";
		}
    }

    private FacesUtils() {
    }
    
    public static Flash getFlash(){
    	return getExternalContext().getFlash();
    }

    public static void showGlobalInfoMessage(String message) {
        showMessage(null, FacesMessage.SEVERITY_INFO, null, message);
    }

    public static void showGlobalWarnMessage(String message) {
        showMessage(null, FacesMessage.SEVERITY_WARN, null, message);
    }

    public static void showGlobalErrorMessage(String message) {
        showMessage(null, FacesMessage.SEVERITY_ERROR, null, message);
    }

    public static void showGlobalFatalMessage(String message) {
        showMessage(null, FacesMessage.SEVERITY_FATAL, null, message);
    }

    public static void showMessage(String clientId, FacesMessage.Severity serSeverity, String summary, String detail) {
        FacesContext context = getFacesContext();
        FacesMessage m = new FacesMessage(serSeverity, summary, detail);
        context.addMessage(clientId, m);
    }

    public static FacesMessage createInfoMessage(String message) {
        return createMessage(FacesMessage.SEVERITY_INFO, message);
    }

    public static FacesMessage createWarnMessage(String message) {
        return createMessage(FacesMessage.SEVERITY_WARN, message);
    }

    public static FacesMessage createErrorMessage(String message) {
        return createMessage(FacesMessage.SEVERITY_ERROR, message);
    }

    public static FacesMessage createFatalMessage(String message) {
        return createMessage(FacesMessage.SEVERITY_FATAL, message);
    }

    public static FacesMessage createMessage(FacesMessage.Severity serSeverity, String message) {
        return createMessage(serSeverity, message, message);
    }

    public static FacesMessage createMessage(FacesMessage.Severity serSeverity, String summary, String detail) {
        return new FacesMessage(serSeverity, summary, detail);
    }

    public static void showClientInfoMessage(String clientId, String message) {
        showMessage(clientId, FacesMessage.SEVERITY_INFO, null, message);
    }

    public static void showClientWarnMessage(String clientId, String message) {
        showMessage(clientId, FacesMessage.SEVERITY_WARN, null, message);
    }

    public static void showClientErrorMessage(String clientId, String message) {
        showMessage(clientId, FacesMessage.SEVERITY_ERROR, null, message);
    }

    public static void showClientFatalMessage(String clientId, String message) {
        showMessage(clientId, FacesMessage.SEVERITY_FATAL, null, message);
    }

    public static HttpServletRequest getRequest() {
        return (HttpServletRequest) getExternalContext().getRequest();
    }
    
    public static HttpSession getHttpSession() {
        return (HttpSession) getExternalContext().getSession(false);
    }

    public static HttpServletRequest getRequest(FacesContext context) {
        return (HttpServletRequest) context.getExternalContext().getRequest();
    }

    public static HttpServletResponse getResponse() {
        return (HttpServletResponse) getExternalContext().getResponse();
    }

    public static HttpServletResponse getResponse(FacesContext context) {
        return (HttpServletResponse) context.getExternalContext().getResponse();
    }

    public static String getParameter(String name) {
        return getExternalContext().getRequestParameterMap().get(name);
    }

	public static ExternalContext getExternalContext() {
	    return getFacesContext().getExternalContext();
    }

	public static FacesContext getFacesContext() {
	    return FacesContext.getCurrentInstance();
    }

    public static String getParameter(FacesContext context, String name) {
        return context.getExternalContext().getRequestParameterMap().get(name);
    }
    
    public static String getCalcCacheKey(Integer userId) {
    	StringBuilder key = new StringBuilder();
    	key.append(JETTY_IPV4);
    	key.append("_");
    	key.append(getHttpSession().getId());
    	key.append("_");
    	key.append(userId);
    	return key.toString();
    }
}
