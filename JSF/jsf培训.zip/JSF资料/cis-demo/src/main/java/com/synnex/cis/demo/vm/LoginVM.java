/**
 * 
 */
package com.synnex.cis.demo.vm;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

import com.synnex.cis.demo.util.FacesUtils;

/**
 * @author Daniel Yang(daniey@synnex.com)
 *
 */
@Named
@ViewScoped
public class LoginVM implements Serializable {

	/**
	 * serial number
	 */
    private static final long serialVersionUID = 2034653176123800172L;
    
    private String name;
    private String password;
    
    public String verify(){
    	if("Billy".equals(name) && "1234".equals(password)) {
    		FacesUtils.getFlash().put("name", name);
    		return "welcome?faces-redirect=true";
    	}else{
    		FacesUtils.showGlobalErrorMessage("Username or password error.");
    		return null;
    	}
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
