/**
 * package com.synnex.arch.demo.jsf2
 * class com.synnex.arch.demo.jsf2.AsResourcesProducer
 * Created on 10/07/2012, 3:55:56 PM
 * @author Diego Lin ^ javafoot
 * ==== LORD JESUS CHRIST SAVE SYNNEX ====
 * ==== Code in the Name of LORD JESUS CHRIST ====
 */
package com.synnex.cis.demo.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.synnex.jee.jsf2.AsResoucesProducerBase;

/**
 * <b>Description</b>: Need an EJB, have to define a method to get it, like the getVirProgramService() method.
 * <p><b>Features or change log:</b>
 * <ol>
 * <li>10/07/2012 3:55:56 PM, DiegoL, C001: </li>
 * <li></li>
 * </ol>
 */
public class AsResourcesProducer extends AsResoucesProducerBase {
    /** Usage:<br>
     * if (LOG.isDebugEnabled()) LOG.debug("latestVer @ {}: {}",artiDir,latestVer);<br>
     * LOG.error("{} is NOT valid in form!",version);
     */
    private static final Logger LOG = LoggerFactory.getLogger(AsResourcesProducer.class);
    
    /**
     * Add one method, if use one EJB.
     * @return
     */
    /*
    @Produces @Named
    public VirProgramService getVirProgramService() {
        return (VirProgramService)getEjbService(VirProgramService.REMOTE);
    }
    */
    
}
/** ==== Glory to GOD ==== */