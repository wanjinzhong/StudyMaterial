/**
 * 
 */
package com.synnex.cis.demo.vm;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.primefaces.context.RequestContext;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortOrder;

import com.synnex.cis.demo.vo.User;

/**
 * @author Daniel Yang(daniey@synnex.com)
 *
 */
@Named
@ViewScoped
public class TestVM implements Serializable {
	/**
	 * serial number
	 */
	private static final long serialVersionUID = -4048195984860583501L;
	private String text;
	private Integer number;
	private LazyDataModel<User> dataModel;
	private List<User> allUsers;

	@PostConstruct
	private void initBean() {

		allUsers = new ArrayList<User>(300);

		for (int i = 1; i < 301; i++) {
			allUsers.add(new User(i, "User" + i, i % 7 == 0 ? "Teacher" : "Student", RandomUtils.nextInt(30) + 15));
		}
		
		dataModel = new LazyDataModel<User>() {

			List<User> list;

			/**
			 * serial number
			 */
			private static final long serialVersionUID = -1610713190255835284L;

			@Override
			public List<User> load(int first, int pageSize, final String sortField, SortOrder sortOrder, Map<String, String> filters) {
				list = new ArrayList<User>();
				List<User> finalList = null;
				List<User> filtered = null;
				if(filters != null && !filters.isEmpty()) {
					filtered = new ArrayList<User>();
					for (User user : allUsers) {
						boolean matched = true;
	                    Iterator<Entry<String, String>> it = filters.entrySet().iterator();
	                    while(it.hasNext()){
	                    	Entry<String, String> entry = it.next();
	                    	try {
	                            Object v1 = PropertyUtils.getProperty(user, entry.getKey());
	                            if(v1 == null || !v1.toString().contains(entry.getValue())){
                            		matched = false;
	                            }
                            } catch (Exception e) {
                            	matched = false;
                            } 
	                    }
	                    
	                    if(matched){
	                    	filtered.add(user);
	                    }
                    }
					
				}
				
				final int order = sortOrder.ordinal() == 0 ? 1 : -1;
				if(filtered == null){
					finalList = allUsers;
				}else{
					finalList = filtered;
				}
				if(sortField != null){
					Collections.sort(finalList, new Comparator<User>() {
						@Override
						public int compare(User o1, User o2) {
							try {
	                            Object v1 = PropertyUtils.getProperty(o1, sortField);
	                            Object v2 = PropertyUtils.getProperty(o2, sortField);
	                            if(v1 == null && v2 == null){
	                            	return 0;
	                            }
	                            
	                            if(v1 != null){
	                            	return (((Comparable)v1).compareTo((Comparable)v2))*order;
	                            }
	                            return 0;
                            } catch (IllegalAccessException e) {
                            } catch (InvocationTargetException e) {
                            } catch (NoSuchMethodException e) {
                            }
							
							return 0;
						}
					});
				}
				
				int end = first + pageSize;
				int lastIndex = finalList.size();
				int last =  end > lastIndex ? lastIndex : end; 
				list = new ArrayList<User>(finalList.subList(first, last));
				setRowCount(lastIndex+1);
				return list;
			}
		};
	}

	public void action1() {
		RequestContext context = RequestContext.getCurrentInstance();
		context.addCallbackParam("user", new User(1, "Daniel Yang", "DEV", 30));
		System.out.println("text: " + text + "  number: " + number);
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public LazyDataModel<User> getDataModel() {
		return dataModel;
	}

	public void setDataModel(LazyDataModel<User> dataModel) {
		this.dataModel = dataModel;
	}
}
