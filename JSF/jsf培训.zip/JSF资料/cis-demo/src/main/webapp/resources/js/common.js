function start() {
    $('#ajaxstatus_start').show();
}
function stop() {
    $('#ajaxstatus_start').hide();
}
function trim(selector, regExp) {
    $(selector).each(function () {
        var $this = $(this);
        $this.html($this.html().replace(new RegExp(regExp, 'gi'), ''));
    });
}


var isPreventFormSubmit = false;
$(function () {
    $(document).on('keydown.preventFormDefault', function (e) {
        if (isPreventFormSubmit && e.keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });
});

(function(win) {
	if (win.Synnex) {
		return;
	}

	win.Synnex = {};

	win.Synnex.utils = {
		showMessage : function(level, message) {
			this.messageUI = $("#messages");
			this.messageUI.children().remove();
			level = level.toLowerCase();
			this.messageBody = $('<div class="ui-messages-' + level
					+ ' ui-corner-all"></div>');
			this.mainBody = $('<div class="ui-messages-'
					+ level
					+ ' ui-corner-all"><a href="#" class="ui-messages-close" onclick="$(this).parent().slideUp();return false;"><span class="ui-icon ui-icon-close"></span></a><span class="ui-messages-'
					+ level + '-icon"></span><ul></ul></div>');
			this.messageItemParent = this.mainBody.find("ul:first");
			this.messageItemParent.children().remove();
			if (Array.isArray(message)) {
				for (var i = 0; i < message.length; i++) {
					this.messageItemParent
							.append($('<li><span class="ui-messages-' + level
									+ '-summary">' + message[i]
									+ '</span></li>'));
				}
			} else {
				this.messageItemParent.append($('<li><span class="ui-messages-'
						+ level + '-summary">' + message + '</span></li>'));
			}
			this.messageUI.append(this.mainBody);
			this.mainBody.show();
		},

		info : function(message) {
			this.showMessage("Info", message);
		},

		error : function(message) {
			this.showMessage("Error", message);
		},

		warn : function(message) {
			this.showMessage("Warn", message);
		},

		fatal : function(message) {
			this.showMessage("Fatal", message);
		},

		clearMessages : function() {
			this.messageUI = $("#messages");
			this.messageUI.children().remove();
		},

		openWindow : function(url) {
			var feature = "toolbar=no,scrollbars=no,statusbar=no,resizable=no,width=1024,height=768";
			return this.openWindow(url, "NewWindow", feature);
		},

		openWindow : function(url, winName) {
			var feature = "toolbar=no,scrollbars=no,statusbar=no,resizable=no,width=1024,height=768";
			return this.openWindow(url, winName, feature);
		},

		openWindow : function(url, winName, feature) {
			return window.open(url, winName, feature);
		}

	};
})(window);